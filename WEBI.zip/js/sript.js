function openmenu() {
    document.getElementById("nav-bar").style.left = "0px";

}

function closemenu() {
    document.getElementById("nav-bar").style.left = "-280px";
}